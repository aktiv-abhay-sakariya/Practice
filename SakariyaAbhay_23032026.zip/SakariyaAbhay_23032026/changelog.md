# Changelog
All notable changes to this project will be documented in this file.

[19.0.1.0.0] :
- Initial release of the module.
- Propagate Job Name in sale.order, stock.picking and account.move models
- Add Sequential Warnings During Sale Order Confirmation using wizard