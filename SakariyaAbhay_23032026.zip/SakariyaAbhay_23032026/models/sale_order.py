# -*- coding: utf-8 -*-

from odoo import api, fields, models


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    job_name = fields.Char(
        string="Job name",
        compute='_compute_job_name',
        store=True,
    )

    @api.depends('opportunity_id.name')
    def _compute_job_name(self):
        """
        set the Job name base on opportunity_id
        """ 
        for rec in self:
            rec.job_name = rec.opportunity_id.name

    def action_confirm(self):
        """
        Override the action_confirm method and check few conditions
        and give a warning message.
        """
        rtn = {
            'type': 'ir.actions.act_window',
            'res_model': 'warning.message.wizard',
            'view_mode': 'form',
            'target': 'new',
        }
        warning_count = self.env.context.get('warning_count', 0)
        if self.partner_id.untrustworthy and warning_count < 1:
            rtn["name"] = 'Customer Trustworthiness'
            rtn["context"] = {
                'default_message': 'This customer is marked as untrustworthy.Do you want to continue?',
                'default_warning_count':1,
                'default_sale_id':self.id
            }
        elif not self.opportunity_id and warning_count < 2:
            rtn["name"] = 'Opportunity Missing'
            rtn["context"] = {
               'default_message': 'This quotation is not linked to any opportunity.Do you want to continue?',
                'default_warning_count':2,
                'default_sale_id':self.id
            }
        elif self.order_line.price_total > 50000 and warning_count < 3:
            rtn["name"] = 'High Quotation Amount'
            rtn["context"] = {
                'default_message': 'The quotation amount exceeds 50,000.Do you want to continue?',
                'default_warning_count':3,
                'default_sale_id':self.id
            }
        else:
            rtn = super().action_confirm()
        return rtn
