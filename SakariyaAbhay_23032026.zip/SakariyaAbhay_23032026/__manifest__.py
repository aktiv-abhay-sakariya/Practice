# -*- coding: utf-8 -*-

{
    'name': 'SakariyaAbhay_23032026',
    'version': '19.0.1.0.0',
    'summary': """Manage sale""",
    'description': "Propagate Job Name and Sequential Warnings During Sale Order Confirmation",
    'category': 'sale',
    'author': 'Abhay sakariya',
    'company': 'Aktiv software',
    'website': 'https://www.aktivsoftware.com/',
    'depends': ['crm', 'sale_management', 'stock'],
    'data': [
       'security/ir.model.access.csv',
       'views/res_partner_views.xml',
       'views/sale_order_views.xml',
       'views/stock_picking_views.xml',
       'views/account_move_view.xml',
       'wizard/warning_message_wizard_view.xml',
    ],
    'license': 'AGPL-3',
    'installable': True,
    'application': False,
    'auto_install': False,
}
