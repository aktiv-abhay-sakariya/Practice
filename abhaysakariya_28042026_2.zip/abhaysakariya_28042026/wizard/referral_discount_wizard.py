# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class ReferralDiscountWizard(models.TransientModel):
    _name = 'referral.discount.wizard'
    _description = 'Apply a discount'

    sale_order_id = fields.Many2one(
        comodel_name='sale.order',
        string='Sale Order'
    )
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Partner'
    )
    selected_discount_id = fields.Many2one(
        comodel_name='referral.discount',
        string='Discount',
        domain="[('partner_id', '=', partner_id),('state', '=', 'active')]"
    )
    expected_discount_amount = fields.Monetary(
        string="Discount Amount ",
        currency_field='currency_id',
        compute = '_compute_expected_discount_amount'
    )
    currency_id = fields.Many2one(
        comodel_name='res.currency',
        string="Currency",
        default=lambda self: self.env.company.currency_id
    )

    @api.depends('selected_discount_id')
    def _compute_expected_discount_amount(self):
        """
        Calculate the expected_discount_amount base on selected discount_id
        """
        self.ensure_one()
        self.expected_discount_amount = self.sale_order_id.amount_untaxed *\
            (self.selected_discount_id.discount_percent / 100)

    def action_apply_discount(self):
        """
        create the product template and set that product to the current
        sale order id.

        Return:
            send a context to the action_confirm method
        """
        product = self.env['product.template'].create({
            'name':'Referral Discount',
            'type':'service','taxes_id':[(5,0,0)],
            'list_price':self.expected_discount_amount * -1
        })
        self.env['sale.order.line'].create({
            'product_id':product.id,
            'product_uom_qty': 1,
            'order_id':self.sale_order_id.id
        })
        self.sale_order_id.applied_discount_id = self.selected_discount_id.id
        return self.sale_order_id.with_context(confirm_order=True).action_confirm()

    def action_not_apply_discount(self):
        """
        confirm the sale order.

        Return:
            send a context to the action_confirm method
        """
        return self.sale_order_id.with_context(confirm_order=True).action_confirm()