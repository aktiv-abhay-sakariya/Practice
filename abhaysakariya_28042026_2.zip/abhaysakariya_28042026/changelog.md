# Changelog
All notable changes to this project will be documented in this file.

[19.0.1.0.0] :
- Initial release of the this module.
- inhert the sale.order model and res.partner model.
- Add the new referral.discount model.

