# -*- coding: utf-8 -*-

from odoo import api, fields, models


class StockPicking(models.Model):
    _inherit = 'stock.picking'
    
    job_name = fields.Char(
        related="sale_id.job_name",
        store=True
    )
