# -*- coding: utf-8 -*-

import random

from odoo import fields, models, api, _
from odoo.exceptions import ValidationError

class ResPartner(models.Model):
    _inherit = 'res.partner'

    referral_code = fields.Char(
        string="Referral Code",
        default="New"
    )
    referred_by_id = fields.Many2one(
        comodel_name='res.partner',
        string='Referred By'
    )
    referral_ids = fields.One2many(
        comodel_name = 'res.partner',
        inverse_name = 'referred_by_id',
        string = 'My Referrals',
    )
    referral_count = fields.Integer(string='Total Referrals', compute='_compute_referral_count', store=True)
    successful_referral_count = fields.Integer(string='Successful Referrals')
    discount_ids = fields.One2many(
        comodel_name = 'referral.discount',
        inverse_name = 'partner_id',
        string = 'discounts',
    )
    active_discount_count = fields.Integer(string='Active Discounts', compute='_compute_active_discount_count', store=True)

    @api.depends('referral_ids')
    def _compute_referral_count(self):
        """
        count the total referralnumbers.
        """
        for rec in self:
            rec.referral_count = len(rec.referral_ids)

    @api.depends('discount_ids.state')
    def _compute_active_discount_count(self):
        """
        count the total no of active discount numbers
        """
        for rec in self:
            total_active_rec = rec.discount_ids.filtered(
                lambda record : record.state == "active"
            )
            total_successful_rec = rec.discount_ids.filtered(
                lambda record : record.state == "used"
            )
            rec.active_discount_count = len(total_active_rec)
            rec.successful_referral_count = len(total_successful_rec)

    @api.model_create_multi
    def create(self, vals):
        """
        Overrides the standard create method to prevent the recursion loop and
        set the referral_code.

        Args:
            vals: A dictionary of fields and values of this model.

        Returns:
            id (object): recordset of created new record.
        """
        for val in vals:
            self._prevent_loop(val)
            if val.get('referral_code', _("New")) == _("New"):
                rand = "%05x" % random.getrandbits(20)
                val['referral_code'] = 'REF-' + rand.upper()
        return super(ResPartner, self).create(vals)

    def write(self, vals):
        """
        Overrides the standard write method to enforce to prevent loop
        during record updates.

        Args:
            vals: A dictionary of fields and values being updated.

        Returns:
            bool: True if a record updated succesfully otherwise False.
        """
        self._prevent_loop(vals)
        return super(ResPartner, self).write(vals)

    def _prevent_loop(self, vals):
        """
        Checks if a record creates a parent-child loop.

        Args:
            vals (dict): A dictionary of fields and values.
        """
        if vals.get('referred_by_id', False):
            if (self.id == vals['referred_by_id'] or
                self._check_category_loop(self.env['res.partner'].search([
                    ('id','=',vals['referred_by_id'])
                ]))):
                raise ValidationError(
                    """You cannot set a referred partner as its own parent"""
                )

    def _check_category_loop(self, partner):
        """
        Recursively checks if a given partner ID is a parent category of
        the current partner.

        Args:
            category : The partner object(recordset) to check in the hierarchy.

        Returns:
            bool: True if a loop is detected otherwise False.
        """
        while partner:
            if partner.id == self.id:
                return True
            partner = partner.referred_by_id
        return False

    def action_send_mail(self):
        """
        Send Welcome Referral mail to the partner
        """
        for rec in self:
            if rec.referred_by_id and rec.email:
                template = self.env.ref(
                    "abhaysakariya_28042026.email_template_res_partner",
                    raise_if_not_found=False
                )
                if not template:
                    raise ValidationError(
                        _("Mail template not found")
                    )
                template.send_mail(
                    self.id,
                    force_send=True,
                    email_values={'email_to':rec.email}
                )
