# -*- coding: utf-8 -*-

from . import res_partner
from . import referral_discount
from . import sale_order
