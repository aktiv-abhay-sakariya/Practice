# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    is_first_order = fields.Boolean(string='First order', default=True)
    applied_discount_id = fields.Many2one(
        comodel_name='referral.discount',
        string='Discount No'
    )
    applied_discount_percent = fields.Float(
        string='Discount',
        compute="_compute_applied_discount_percent",
        store=True
    )

    @api.depends('applied_discount_id')
    def _compute_applied_discount_percent(self):
        """
        Calcululate the discount percentage base on selected discount id.
        """
        self.ensure_one()
        self.applied_discount_percent = self.applied_discount_id.discount_percent

    @api.model_create_multi
    def create(self, vals):
        """
        Overrides the standard create method to set the is_first_order field.

        Args:
            vals: A dictionary of fields and values of this model.

        Returns:
            id (object): recordset of created new record.
        """
        for val in vals:
            if val.get('partner_id', False) and \
            self.env['sale.order'].search_count([
                ('partner_id','=',val['partner_id']),
                ('state','=','sale')
            ]):
                val['is_first_order'] = False
        return super(SaleOrder, self).create(vals)

    def action_confirm(self):
        """
        Overrides the odoo standard action_confirm method create a record of
        referral.discount model and open a wizard for add a discount.
        """
        self.ensure_one()
        if not self.env.context.get('confirm_order', False):
            if self.is_first_order and self.partner_id.referred_by_id and\
                self.amount_untaxed >= 1000:
                discount_model = self.env['referral.discount']
                self.applied_discount_id = discount_model.create({
                    'partner_id':self.partner_id.id,
                    'source_partner_id':self.partner_id.referred_by_id.id,
                    'reason':'referee_welcome',
                    'discount_percent':20,
                    'source_sale_order_id':self.id,
                }).id
                discount_model.create({
                    'partner_id':self.partner_id.referred_by_id.id,
                    'source_partner_id':self.partner_id.id,
                    'reason':'referrer_reward',
                    'discount_percent':10,
                    'source_sale_order_id':self.id,
                })
                template = self.env.ref(
                    "abhaysakariya_28042026.email_template_sale_order",
                    raise_if_not_found=False
                )
                if not template:
                    raise ValidationError(
                        _("Mail template not found")
                    )
                template.send_mail(
                    self.id,
                    force_send=True,
                    email_values={'recipient_ids':[
                        (4, self.partner_id.id),
                        (4, self.partner_id.referred_by_id.id)
                    ]}
                )
                rtn = super().action_confirm()
            elif not self.applied_discount_id:
                discounts = self.env['referral.discount'].search_count([
                    ('partner_id','=',self.partner_id.id),
                    ('state','=','active')
                ])
                if discounts:
                    rtn = {
                        'name': _("Apply Referral Discount on Confirm"),
                        'type': 'ir.actions.act_window',
                        'res_model': 'referral.discount.wizard',
                        'view_mode': 'form',
                        'target': 'new',
                        'context': {
                            'default_sale_order_id':self.id,
                            'default_partner_id':self.partner_id.id,
                        }
                    }
                else:
                    rtn = super().action_confirm()
            else:
                rtn = super().action_confirm()
        else:
            if self.applied_discount_id:
                self.applied_discount_id.update({
                    'source_sale_order_id':self.id,
                    'state':'used',
                })
            rtn = super().action_confirm()
        return rtn