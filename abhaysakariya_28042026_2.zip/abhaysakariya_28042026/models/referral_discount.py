# -*- coding: utf-8 -*-

from datetime import timedelta

from odoo import fields, models, api, _
from odoo.exceptions import ValidationError

class ReferralDiscount(models.Model):
    _name = 'referral.discount'
    _description = "Discounts"

    name = fields.Char(string="Sequence", default='New')
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Partner',
        required=True
    )
    source_partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Partner ref'
    )
    reason = fields.Selection([
        ('referrer_reward', 'Referrer Reward'),
        ('referee_welcome', 'Referee Welcome')
    ],
        string = "Reason",
        default='referrer_reward',
    )
    discount_percent = fields.Float(string='Discount')
    source_sale_order_id = fields.Many2one(
        comodel_name='sale.order',
        string='sale order'
    )
    redeemed_sale_order_id = fields.Many2one(
        comodel_name='sale.order',
        string='Sale order'
    )
    earned_date = fields.Date(string='Earn Date', default=fields.Date.today())
    expiry_date = fields.Date(string='Expriry Date', default=fields.Date.today() + timedelta(days=365))
    state = fields.Selection([
        ('active', 'Active'),
        ('used', 'Used'),
        ('expired', 'Expired')
    ],
        string = "State",
        default='active',
    )

    @api.constrains('discount_percent')
    def _check_discount_percent(self):
        """
        Ensure that discount is must be greater than 0 and less than or equal
        to 50

        Raise: class:'ValidationError'.
        """
        for rec in self:
            if 0 >= rec.discount_percent < 50:
                raise ValidationError(
                    _(
                        """Discount percent must be greater than 0 and less than
                      or equal to 50."""
                    )
                )

    @api.constrains('partner_id', 'source_partner_id')
    def _check_partner_source_partner(self):
        """
        Ensure that partner and source partner fiiled.

        Raise: class:'ValidationError'.
        """
        for rec in self:
            if not rec.partner_id or not rec.source_partner_id or\
                rec.partner_id == rec.source_partner_id:
                raise ValidationError(
                    _(
                        """Both Partner and Source Partner must be filled and
                        must be different partners"""
                    )
                )

    @api.model_create_multi
    def create(self, vals):
        """
        Overrides the standard create method to set a next sequence.

        Args:
            vals: A dictionary of fields and values of this model.

        Returns:
            id (object): recordset of created new record.
        """
        for val in vals:
            if val.get('name', _("New")) == _("New"):
                val['name'] = self.env['ir.sequence'].next_by_code(
                    'referral.discount'
                ) or _("New")
        return super(ReferralDiscount, self).create(vals)