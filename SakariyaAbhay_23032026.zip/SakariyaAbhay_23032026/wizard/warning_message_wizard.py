# -*- coding: utf-8 -*-

from odoo import fields, models


class TrustworthyWarning(models.TransientModel):
    _name = "warning.message.wizard"
    _description = "warning message"
    
    message = fields.Char()
    warning_count = fields.Integer()
    sale_id = fields.Many2one('sale.order')
    
    def action_confirm_warning(self):
        return self.sale_id.with_context(
            warning_count=self.warning_count
        ).action_confirm()
