# -*- coding: utf-8 -*-

from odoo import api, fields, models


class AccountMove(models.Model):
    _inherit = 'account.move'
    
    job_name = fields.Char(
        relat ed='invoice_line_ids.sale_line_ids.order_id.job_name',
        store=True
    )
    # job_name = fields.Char(compute='_compute_job_name',store=True)
    
    # @api.depends('invoice_line_ids.sale_line_ids.order_id.job_name')
    # def _compute_job_name(self):
    #     for rec in self:
    #         rec.job_name = rec.invoice_line_ids.sale_line_ids.order_id.job_name
    #     # print('\n\naccount ----- ',self.invoice_line_ids.sale_line_ids.order_id)
    #     # invoice_line_ids.sale_line_ids.